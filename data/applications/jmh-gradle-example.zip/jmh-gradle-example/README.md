jmh-gradle-example
==================

Sample project showcasing the JMH gradle plugin

Clone this repository, then change directory and type:

```./gradlew jmh```

